var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/home', function(req, res, next) {
  db.query('SELECT sum(deaths)from Covid_details', function (err, result) {
    if (err) throw err;
      console.log({data:result})
    ///res.render() function
    res.render('home',{data:result});
  });
});

module.exports = router;
